﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2020.2.3),
    on 9月 10, 2020, at 00:01
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2020.2.3'
expName = 'challenge'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sort_keys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\asako\\OneDrive\\デスクトップ\\ariga (1)\\ariga\\challenge_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True)
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "trial_cross"
trial_crossClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "trial"
trialClock = core.Clock()
mouse = event.Mouse(win=win)
x, y = [None, None]
mouse.mouseClock = core.Clock()
G_1 = visual.ImageStim(
    win=win,
    name='G_1', 
    image='Gu.JPG', mask=None,
    ori=0, pos=(-0.25, 0), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
C_1 = visual.ImageStim(
    win=win,
    name='C_1', 
    image='Choki.JPG', mask=None,
    ori=0, pos=(0, 0), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
P_1 = visual.ImageStim(
    win=win,
    name='P_1', 
    image='Pa.JPG', mask=None,
    ori=0, pos=(0.25, 0), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)

# Initialize components for Routine "trial_chosen"
trial_chosenClock = core.Clock()
G_2 = visual.ImageStim(
    win=win,
    name='G_2', 
    image='Gu.JPG', mask=None,
    ori=0, pos=(-0.25, 0), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
C_2 = visual.ImageStim(
    win=win,
    name='C_2', 
    image='Choki.JPG', mask=None,
    ori=0, pos=(0, 0), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
P_2 = visual.ImageStim(
    win=win,
    name='P_2', 
    image='Pa.JPG', mask=None,
    ori=0, pos=(0.25, 0), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
gray1 = visual.ImageStim(
    win=win,
    name='gray1', 
    image='gray1.png', mask=None,
    ori=0, pos=[0,0], size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=0.8,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-3.0)
gray2 = visual.ImageStim(
    win=win,
    name='gray2', 
    image='gray1.png', mask=None,
    ori=0, pos=[0,0], size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=0.8,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)
image_opponent = visual.ImageStim(
    win=win,
    name='image_opponent', 
    image='sin', mask=None,
    ori=0, pos=(0, 0.5), size=(0.2, 0.3),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-5.0)
text_result = visual.TextStim(win=win, name='text_result',
    text='default text',
    font='Arial',
    pos=(0, -0.5), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=5, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Book1.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "trial_cross"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    # keep track of which components have finished
    trial_crossComponents = [text]
    for thisComponent in trial_crossComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    trial_crossClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "trial_cross"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = trial_crossClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=trial_crossClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trial_crossComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trial_cross"-------
    for thisComponent in trial_crossComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addData('text.started', text.tStartRefresh)
    trials.addData('text.stopped', text.tStopRefresh)
    
    # ------Prepare to start Routine "trial"-------
    continueRoutine = True
    # update component parameters for each repeat
    # setup some python lists for storing info about the mouse
    mouse.clicked_name = []
    gotValidClick = False  # until a click is received
    mouse.mouseClock.reset()
    # keep track of which components have finished
    trialComponents = [mouse, G_1, C_1, P_1]
    for thisComponent in trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "trial"-------
    while continueRoutine:
        # get current time
        t = trialClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=trialClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # *mouse* updates
        if mouse.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse.frameNStart = frameN  # exact frame index
            mouse.tStart = t  # local t and not account for scr refresh
            mouse.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse, 'tStartRefresh')  # time at next scr refresh
            mouse.status = STARTED
            prevButtonState = mouse.getPressed()  # if button is down already this ISN'T a new click
        if mouse.status == STARTED:  # only update if started and not finished!
            buttons = mouse.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    for obj in [G_1,C_1,P_1]:
                        if obj.contains(mouse):
                            gotValidClick = True
                            mouse.clicked_name.append(obj.name)
                    if gotValidClick:  # abort routine on response
                        continueRoutine = False
        
        # *G_1* updates
        if G_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            G_1.frameNStart = frameN  # exact frame index
            G_1.tStart = t  # local t and not account for scr refresh
            G_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(G_1, 'tStartRefresh')  # time at next scr refresh
            G_1.setAutoDraw(True)
        
        # *C_1* updates
        if C_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            C_1.frameNStart = frameN  # exact frame index
            C_1.tStart = t  # local t and not account for scr refresh
            C_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(C_1, 'tStartRefresh')  # time at next scr refresh
            C_1.setAutoDraw(True)
        
        # *P_1* updates
        if P_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            P_1.frameNStart = frameN  # exact frame index
            P_1.tStart = t  # local t and not account for scr refresh
            P_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(P_1, 'tStartRefresh')  # time at next scr refresh
            P_1.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trial"-------
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store data for trials (TrialHandler)
    x, y = mouse.getPos()
    buttons = mouse.getPressed()
    if sum(buttons):
        # check if the mouse was inside our 'clickable' objects
        gotValidClick = False
        for obj in [G_1,C_1,P_1]:
            if obj.contains(mouse):
                gotValidClick = True
                mouse.clicked_name.append(obj.name)
    trials.addData('mouse.x', x)
    trials.addData('mouse.y', y)
    trials.addData('mouse.leftButton', buttons[0])
    trials.addData('mouse.midButton', buttons[1])
    trials.addData('mouse.rightButton', buttons[2])
    if len(mouse.clicked_name):
        trials.addData('mouse.clicked_name', mouse.clicked_name[0])
    trials.addData('mouse.started', mouse.tStart)
    trials.addData('mouse.stopped', mouse.tStop)
    trials.addData('G_1.started', G_1.tStartRefresh)
    trials.addData('G_1.stopped', G_1.tStopRefresh)
    trials.addData('C_1.started', C_1.tStartRefresh)
    trials.addData('C_1.stopped', C_1.tStopRefresh)
    trials.addData('P_1.started', P_1.tStartRefresh)
    trials.addData('P_1.stopped', P_1.tStopRefresh)
    if mouse.isPressedIn(G_1):
        gray1_posi = (0,0)
        gray2_posi = (0.25,0)
        if opponent == "Gu.JPG":
            result = "ひきわけ"
            resultcolor = "white"
        elif opponent == "Choki.JPG":
            result = "勝ち"
            resultcolor = "red"
        else:
            result = "負け"
            resultcolor = "blue"
    if mouse.isPressedIn(C_1):
        gray1_posi = (-0.25,0)
        gray2_posi = (0.25,0)
        if opponent == "Gu.JPG":
            result = "負け"
            resultcolor = "blue"
        elif opponent == "Choki.JPG":
            result = "ひきわけ"
            resultcolor = "white"
        else:
            result = "勝ち"
            resultcolor = "red"
    if mouse.isPressedIn(P_1):
        gray1_posi = (-0.25,0)
        gray2_posi = (0,0)
        if opponent == "Gu.JPG":
            result = "勝ち"
            resultcolor = "red"
        elif opponent == "Choki.JPG":
            result = "負け"
            resultcolor = "blue"
        else:
            result = "ひきわけ"
            resultcolor = "white"
    
    trials.addData('Result', result)
    # the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "trial_chosen"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    gray1.setPos(gray1_posi)
    gray2.setPos(gray2_posi)
    image_opponent.setImage(opponent)
    text_result.setColor(resultcolor, colorSpace='rgb')
    text_result.setText(result)
    # keep track of which components have finished
    trial_chosenComponents = [G_2, C_2, P_2, gray1, gray2, image_opponent, text_result]
    for thisComponent in trial_chosenComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    trial_chosenClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "trial_chosen"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = trial_chosenClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=trial_chosenClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *G_2* updates
        if G_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            G_2.frameNStart = frameN  # exact frame index
            G_2.tStart = t  # local t and not account for scr refresh
            G_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(G_2, 'tStartRefresh')  # time at next scr refresh
            G_2.setAutoDraw(True)
        if G_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > G_2.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                G_2.tStop = t  # not accounting for scr refresh
                G_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(G_2, 'tStopRefresh')  # time at next scr refresh
                G_2.setAutoDraw(False)
        
        # *C_2* updates
        if C_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            C_2.frameNStart = frameN  # exact frame index
            C_2.tStart = t  # local t and not account for scr refresh
            C_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(C_2, 'tStartRefresh')  # time at next scr refresh
            C_2.setAutoDraw(True)
        if C_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > C_2.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                C_2.tStop = t  # not accounting for scr refresh
                C_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(C_2, 'tStopRefresh')  # time at next scr refresh
                C_2.setAutoDraw(False)
        
        # *P_2* updates
        if P_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            P_2.frameNStart = frameN  # exact frame index
            P_2.tStart = t  # local t and not account for scr refresh
            P_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(P_2, 'tStartRefresh')  # time at next scr refresh
            P_2.setAutoDraw(True)
        if P_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > P_2.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                P_2.tStop = t  # not accounting for scr refresh
                P_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(P_2, 'tStopRefresh')  # time at next scr refresh
                P_2.setAutoDraw(False)
        
        # *gray1* updates
        if gray1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            gray1.frameNStart = frameN  # exact frame index
            gray1.tStart = t  # local t and not account for scr refresh
            gray1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(gray1, 'tStartRefresh')  # time at next scr refresh
            gray1.setAutoDraw(True)
        if gray1.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > gray1.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                gray1.tStop = t  # not accounting for scr refresh
                gray1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(gray1, 'tStopRefresh')  # time at next scr refresh
                gray1.setAutoDraw(False)
        
        # *gray2* updates
        if gray2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            gray2.frameNStart = frameN  # exact frame index
            gray2.tStart = t  # local t and not account for scr refresh
            gray2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(gray2, 'tStartRefresh')  # time at next scr refresh
            gray2.setAutoDraw(True)
        if gray2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > gray2.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                gray2.tStop = t  # not accounting for scr refresh
                gray2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(gray2, 'tStopRefresh')  # time at next scr refresh
                gray2.setAutoDraw(False)
        
        # *image_opponent* updates
        if image_opponent.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_opponent.frameNStart = frameN  # exact frame index
            image_opponent.tStart = t  # local t and not account for scr refresh
            image_opponent.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_opponent, 'tStartRefresh')  # time at next scr refresh
            image_opponent.setAutoDraw(True)
        if image_opponent.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > image_opponent.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                image_opponent.tStop = t  # not accounting for scr refresh
                image_opponent.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image_opponent, 'tStopRefresh')  # time at next scr refresh
                image_opponent.setAutoDraw(False)
        
        # *text_result* updates
        if text_result.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            text_result.frameNStart = frameN  # exact frame index
            text_result.tStart = t  # local t and not account for scr refresh
            text_result.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_result, 'tStartRefresh')  # time at next scr refresh
            text_result.setAutoDraw(True)
        if text_result.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_result.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                text_result.tStop = t  # not accounting for scr refresh
                text_result.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_result, 'tStopRefresh')  # time at next scr refresh
                text_result.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trial_chosenComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "trial_chosen"-------
    for thisComponent in trial_chosenComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addData('G_2.started', G_2.tStartRefresh)
    trials.addData('G_2.stopped', G_2.tStopRefresh)
    trials.addData('C_2.started', C_2.tStartRefresh)
    trials.addData('C_2.stopped', C_2.tStopRefresh)
    trials.addData('P_2.started', P_2.tStartRefresh)
    trials.addData('P_2.stopped', P_2.tStopRefresh)
    trials.addData('gray1.started', gray1.tStartRefresh)
    trials.addData('gray1.stopped', gray1.tStopRefresh)
    trials.addData('gray2.started', gray2.tStartRefresh)
    trials.addData('gray2.stopped', gray2.tStopRefresh)
    trials.addData('image_opponent.started', image_opponent.tStartRefresh)
    trials.addData('image_opponent.stopped', image_opponent.tStopRefresh)
    trials.addData('text_result.started', text_result.tStartRefresh)
    trials.addData('text_result.stopped', text_result.tStopRefresh)
    thisExp.nextEntry()
    
# completed 5 repeats of 'trials'


# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
